
This font is made by APlaPi, and he is glad that you like it (I can tell).
You MUST NOT sell, rent, license or redistribute the font without my explicit permission.
If you need a license feel free to ask. For any other information e-mail me at abrahamplapi@gmail.com

 - --  PayPal donations will be welcome and very much appreciated.  -- -

Thank you
APlaPi
